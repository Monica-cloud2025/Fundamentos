using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
public class Programa
{
    private List<Usuario> usuarios;
    private Usuario? usuarioLogueado;

    public Programa()
    {
        usuarios = new List<Usuario>();
        usuarioLogueado = null;
    }

    public void RegistrarUsuario()
    {
        Console.WriteLine("Registro del programa de Entrenamiento ");
        Console.WriteLine("Introduce tu correo:");
        string correo = Console.ReadLine();

        Console.WriteLine("Introduce tu contraseña:");
        string contraseña = Console.ReadLine();

        if (usuarios.Exists(u => u.Correo == correo))
        {
            Console.WriteLine("Ya existe un usuario con ese correo.");
        }
        else
        {
            usuarios.Add(new Usuario(correo, contraseña));
            Console.WriteLine("Usuario registrado correctamente.");
        }
    }

    public void LoguearUsuario()
    {
        Console.WriteLine("Inicio de Sesión del programa de Entrenamiento ");
        Console.WriteLine("Introduce tu correo:");
        string correo = Console.ReadLine();

        Console.WriteLine("Introduce tu contraseña:");
        string contraseña = Console.ReadLine();

        usuarioLogueado = usuarios.Find(u => u.Correo == correo && u.Contraseña == contraseña);

        if (usuarioLogueado != null)
        {
            Console.WriteLine("Usuario logueado correctamente.");
            MenuUsuario();
        }
        else
        {
            Console.WriteLine("Correo o contraseña incorrectos.");
        }
    }

    public void RegistrarEntrenamiento()
    {
        Console.WriteLine("Dime la distancia que has recorrido (en km):");
        double distancia = double.Parse(Console.ReadLine());

        Console.WriteLine("Dime en qué tiempo lo has recorrido (en horas:minutos:segundos):");
        TimeSpan tiempo = TimeSpan.Parse(Console.ReadLine());

        usuarioLogueado.Entrenamientos.Add(new Entrenamiento(distancia, tiempo));
        Console.WriteLine("Entrenamiento registrado correctamente.");
    }

    public void ListarEntrenamientos()
    {
        if (usuarioLogueado.Entrenamientos.Count == 0)
        {
            Console.WriteLine("No hay entrenamientos registrados.");
        }
        else
        {
            foreach (var entrenamiento in usuarioLogueado.Entrenamientos)
            {
                Console.WriteLine(entrenamiento);
            }
        }
    }

    public void VaciarEntrenamientos()
    {
        usuarioLogueado.Entrenamientos.Clear();
        Console.WriteLine("Entrenamientos vaciados correctamente.");
    }

    public void MenuPrincipal()
    {
        int opcion;
        do
        {
            Console.WriteLine("\nMenú del programa de Entrenamiento");
            Console.WriteLine("1. Registro nuevo usuario");
            Console.WriteLine("2. Inicio Sesión usuario");
            Console.WriteLine("3. Salir");
            Console.Write("Introduce una opción: ");

            if (int.TryParse(Console.ReadLine(), out opcion))
            {
                switch (opcion)
                {
                    case 1:
                        RegistrarUsuario();
                        break;
                    case 2:
                        LoguearUsuario();
                        break;
                    case 3:
                        break;
                    default:
                        Console.WriteLine("Opción inválida.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Opción incorrecta. Por favor seleccione una opción del menú.");
            }
        } while (opcion != 3);
    }

    public void MenuUsuario()
    {
        int opcion;
        do
        {
            Console.WriteLine("\nMenú del programa de Entrenamiento.Introduce una opción");
            Console.WriteLine("1. Registrar un entrenamiento");
            Console.WriteLine("2. Listar tus entrenamientos");
            Console.WriteLine("3. Vaciar tus entrenamientos");
            Console.WriteLine("4. Cerrar sesión");
            Console.Write("Ingrese una opción: ");

            if (int.TryParse(Console.ReadLine(), out opcion))
            {
                switch (opcion)
                {
                    case 1:
                        RegistrarEntrenamiento();
                        break;
                    case 2:
                        ListarEntrenamientos();
                        break;
                    case 3:
                        VaciarEntrenamientos();
                        break;
                    case 4:
                        usuarioLogueado = null;
                        Console.WriteLine("Cerrando Sesión...");
                        return;
                    default:
                        Console.WriteLine("Opción inválida.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Opción incorrecta. Por favor seleccione una opción del menú.");
            }
        } while (true);
    }
}