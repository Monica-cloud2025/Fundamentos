using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
public class Usuario
{
    public string Correo { get; set; }
    public string Contraseña { get; set; }
    public List<Entrenamiento> Entrenamientos { get; set; }

    public Usuario(string correo, string contraseña)
    {
        Correo = correo;
        Contraseña = contraseña;
        Entrenamientos = new List<Entrenamiento>();
    }
}

public class Entrenamiento
{
    private double Distancia { get; set; }
    private TimeSpan Tiempo { get; set; }

    public Entrenamiento(double distancia, TimeSpan tiempo)
    {
        Distancia = distancia;
        Tiempo = tiempo;
    }

    public override string ToString()
    {
        return $"Distancia: {Distancia} km, Tiempo: {Tiempo.ToString(@"hh\:mm\:ss")}";
    }
}