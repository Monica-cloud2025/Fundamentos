﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

    public class Entrada
    {
        public static void Main(string[]args)
        {
            Programa programa = new Programa();
            programa.MenuPrincipal();
        }

    }  